# COVID-19 in the USA

Projekt analizy i wizualizacji danych COVID-19 dla USA. Ten pakiet zawiera strukturę katalogów, skrypty, automatyczne pobieranie danych, przygotowanie danych, generowanie wykresów interaktywnych HTML oraz tabele wynikowe. Nie zawiera finalnej prezentacji PDF/postera ani gotowej prezentacji HTML.

## Jak uruchomić w PowerShell

Wejdź do katalogu projektu:

```powershell
cd covid19_USA
```

Najprościej uruchom:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_and_run.ps1
```

Po zakończeniu otwórz:

```powershell
.\html\index.html
```

## Struktura

```text
covid19_USA/
  data/
  html/
  output/
  scripts/
  requirements.txt
  run_all.ps1
  setup_and_run.ps1
  README.md
```

## Dane

Główne dane są pobierane z Our World in Data:

```text
https://catalog.ourworldindata.org/garden/covid/latest/compact/compact.csv
```

Skrypt ma też drugi adres awaryjny:

```text
https://covid.ourworldindata.org/data/owid-covid-data.csv
```

## Co robią skrypty

`00_download_data.py` pobiera plik `compact.csv` do katalogu `data`.

`01_prepare_data.py` filtruje dane dla USA, Polski i świata, porządkuje daty oraz liczy dodatkowe wskaźniki, np. case fatality rate.

`02_summary_statistics.py` tworzy podstawowe statystyki opisowe i wykresy podsumowujące dla USA.

`03_cases_deaths_trends.py` tworzy wykresy trendów dziennych, skumulowanych przypadków i zgonów oraz tabelę dni szczytowych.

`04_usa_vs_poland.py` porównuje USA z Polską na danych per million i na najnowszych dostępnych wskaźnikach.

`05_vaccination_analysis.py` tworzy wykresy szczepień oraz animację relacji poziomu zaszczepienia i zgonów.

`06_hospital_testing.py` tworzy wykresy hospitalizacji, ICU i testowania, jeśli odpowiednie kolumny są dostępne w danych.

`07_inferential_regression.py` tworzy regresję log-liniową dla okresów 2020-2022, 2020-2024 i ostatnich 180 dni oraz prostą prognozę 60-dniową.

`08_build_dashboard.py` buduje plik `html/index.html`, który zbiera linki do wszystkich wygenerowanych wykresów.

## Wyniki

Interaktywne wykresy trafiają do katalogu `html`.

Tabele CSV z wynikami pośrednimi trafiają do katalogu `output`.

Przetworzone dane trafiają do katalogu `data`.
