from pathlib import Path
import pandas as pd
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HTML = ROOT / "html"
OUTPUT = ROOT / "output"
HTML.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)

usa = pd.read_csv(DATA / "covid_usa.csv", parse_dates=["date"])
usa = usa.sort_values("date")

hospital_columns = [column for column in ["hosp_patients_per_million", "icu_patients_per_million", "weekly_hosp_admissions_per_million", "weekly_icu_admissions_per_million"] if column in usa.columns]
if hospital_columns:
    hospital = usa.melt(id_vars="date", value_vars=hospital_columns, var_name="metric", value_name="value").dropna()
    hospital.to_csv(OUTPUT / "usa_hospital_icu_data.csv", index=False)
    fig = px.line(hospital, x="date", y="value", color="metric", title="COVID-19 in the USA: hospital and ICU indicators", labels={"date": "Date", "value": "Per million", "metric": "Metric"})
    fig.update_layout(template="plotly_dark", hovermode="x unified")
    fig.write_html(HTML / "13_usa_hospital_icu.html")

testing_columns = [column for column in ["positive_rate", "new_tests_smoothed_per_thousand", "tests_per_case"] if column in usa.columns]
if testing_columns:
    testing = usa.melt(id_vars="date", value_vars=testing_columns, var_name="metric", value_name="value").dropna()
    testing.to_csv(OUTPUT / "usa_testing_data.csv", index=False)
    fig2 = px.line(testing, x="date", y="value", color="metric", facet_row="metric", title="COVID-19 in the USA: testing indicators", labels={"date": "Date", "value": "Value", "metric": "Metric"})
    fig2.update_yaxes(matches=None)
    fig2.update_layout(template="plotly_dark", hovermode="x unified", showlegend=False)
    fig2.write_html(HTML / "14_usa_testing.html")
