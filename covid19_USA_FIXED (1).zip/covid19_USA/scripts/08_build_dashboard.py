from pathlib import Path
import html

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / "html"
HTML.mkdir(exist_ok=True)

files = sorted(path for path in HTML.glob("*.html") if path.name != "index.html")
items = "\n".join(f"<li><a href='{html.escape(path.name)}'>{html.escape(path.stem.replace('_', ' '))}</a></li>" for path in files)
content = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>COVID-19 in the USA: plot dashboard</title>
<style>
body {{ margin: 0; font-family: Arial, sans-serif; background: #111827; color: #f9fafb; }}
main {{ max-width: 1100px; margin: 0 auto; padding: 40px 24px; }}
h1 {{ font-size: 42px; margin-bottom: 8px; }}
p {{ line-height: 1.6; color: #d1d5db; }}
.grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-top: 28px; }}
li {{ margin: 10px 0; }}
a {{ color: #93c5fd; text-decoration: none; }}
a:hover {{ text-decoration: underline; }}
.card {{ background: #1f2937; border-radius: 18px; padding: 22px; box-shadow: 0 10px 30px rgba(0,0,0,0.25); }}
</style>
</head>
<body>
<main>
<h1>COVID-19 in the USA</h1>
<p>Dashboard z interaktywnymi wykresami wygenerowanymi przez skrypty projektu. To nie jest finalna prezentacja ani poster, tylko lista wyników do wykorzystania w prezentacji.</p>
<div class="card">
<h2>Wykresy</h2>
<ul>
{items}
</ul>
</div>
<div class="grid">
<div class="card"><h2>Summary statistics</h2><p>Podstawowe liczby: przypadki, zgony, wskaźniki na milion, case fatality rate, szczepienia.</p></div>
<div class="card"><h2>Inferential statistics</h2><p>Regresja log-liniowa dla dwóch okresów oraz prosta prognoza trendu na 60 dni.</p></div>
<div class="card"><h2>Comparison</h2><p>Porównanie USA z Polską na wykresach per capita, zgodnie z możliwością użycia Polski jako kraju porównawczego.</p></div>
</div>
</main>
</body>
</html>
"""
(HTML / "index.html").write_text(content, encoding="utf-8")
print(f"Zapisano: {HTML / 'index.html'}")
