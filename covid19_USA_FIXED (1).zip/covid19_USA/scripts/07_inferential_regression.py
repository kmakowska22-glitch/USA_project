from pathlib import Path
import numpy as np
import pandas as pd
import plotly.graph_objects as go

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HTML = ROOT / "html"
OUTPUT = ROOT / "output"
HTML.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)

usa = pd.read_csv(DATA / "covid_usa.csv", parse_dates=["date"])
usa = usa.sort_values("date")
TARGET = "new_cases_smoothed_per_million" if "new_cases_smoothed_per_million" in usa.columns else "new_cases_smoothed"


def fit_log_linear(frame, label, start, end):
    part = frame[(frame["date"] >= pd.Timestamp(start)) & (frame["date"] <= pd.Timestamp(end))][["date", TARGET]].dropna().copy()
    part = part[part[TARGET] >= 0]
    if len(part) < 30:
        return None, None
    x = (part["date"] - part["date"].min()).dt.days.to_numpy(dtype=float)
    y = np.log1p(part[TARGET].to_numpy(dtype=float))
    slope, intercept = np.polyfit(x, y, 1)
    fitted = np.expm1(intercept + slope * x)
    residual = y - (intercept + slope * x)
    ss_res = float(np.sum(residual ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot != 0 else np.nan
    output = part.copy()
    output["label"] = label
    output["fitted"] = fitted
    row = {
        "period": label,
        "start": part["date"].min().date().isoformat(),
        "end": part["date"].max().date().isoformat(),
        "n_days": len(part),
        "slope_log": slope,
        "daily_percent_change": (np.exp(slope) - 1) * 100,
        "r2_log_model": r2
    }
    return row, output

available_end = usa[["date", TARGET]].dropna()["date"].max()
periods = [
    ("2020-2022", "2020-03-01", "2022-12-31"),
    ("2020-2024", "2020-03-01", "2024-12-31"),
    ("last 180 available days", available_end - pd.Timedelta(days=179), available_end)
]

rows = []
fits = []
for label, start, end in periods:
    row, fitted = fit_log_linear(usa, label, start, end)
    if row is not None:
        rows.append(row)
        fits.append(fitted)

stats = pd.DataFrame(rows)
stats.to_csv(OUTPUT / "usa_regression_statistics.csv", index=False)

fig = go.Figure()
observed = usa[["date", TARGET]].dropna()
fig.add_trace(go.Scatter(x=observed["date"], y=observed[TARGET], name="Observed", mode="lines"))
for fitted in fits:
    fig.add_trace(go.Scatter(x=fitted["date"], y=fitted["fitted"], name=f"Fitted: {fitted['label'].iloc[0]}", mode="lines"))
fig.update_layout(title=f"COVID-19 in the USA: log-linear regression of {TARGET}", template="plotly_dark", hovermode="x unified", xaxis_title="Date", yaxis_title=TARGET)
fig.write_html(HTML / "15_usa_regression_periods.html")

forecast_source = usa[["date", TARGET]].dropna().tail(180).copy()
forecast_source = forecast_source[forecast_source[TARGET] >= 0]
if len(forecast_source) >= 30:
    x = (forecast_source["date"] - forecast_source["date"].min()).dt.days.to_numpy(dtype=float)
    y = np.log1p(forecast_source[TARGET].to_numpy(dtype=float))
    slope, intercept = np.polyfit(x, y, 1)
    future_dates = pd.date_range(forecast_source["date"].max() + pd.Timedelta(days=1), periods=60, freq="D")
    future_x = (future_dates - forecast_source["date"].min()).days.to_numpy(dtype=float)
    future_values = np.maximum(0, np.expm1(intercept + slope * future_x))
    forecast = pd.DataFrame({"date": future_dates, "forecast": future_values})
    forecast.to_csv(OUTPUT / "usa_60_day_case_forecast.csv", index=False)
    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(x=forecast_source["date"], y=forecast_source[TARGET], name="Last 180 days observed", mode="lines"))
    fig2.add_trace(go.Scatter(x=forecast["date"], y=forecast["forecast"], name="60-day forecast", mode="lines"))
    fig2.update_layout(title=f"COVID-19 in the USA: simple 60-day forecast of {TARGET}", template="plotly_dark", hovermode="x unified", xaxis_title="Date", yaxis_title=TARGET)
    fig2.write_html(HTML / "16_usa_60_day_forecast.html")
