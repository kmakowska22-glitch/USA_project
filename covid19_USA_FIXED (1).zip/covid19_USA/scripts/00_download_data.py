from pathlib import Path
import requests

URLS = [
    "https://covid.ourworldindata.org/data/owid-covid-data.csv",
    "https://raw.githubusercontent.com/owid/covid-19-data/master/public/data/owid-covid-data.csv"
]

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
TARGET = DATA / "compact.csv"
TMP = DATA / "compact.tmp.csv"
REQUIRED_COLUMNS = {"iso_code", "location", "date"}


def download_file(url, target):
    with requests.get(url, stream=True, timeout=120) as response:
        response.raise_for_status()
        with open(target, "wb") as file:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    file.write(chunk)


def valid_file(path):
    if not path.exists() or path.stat().st_size <= 1000000:
        return False
    with open(path, "r", encoding="utf-8", errors="replace") as file:
        header = file.readline().strip().split(",")
    return REQUIRED_COLUMNS.issubset(set(header))


last_error = None
for url in URLS:
    try:
        print(f"Pobieram dane z: {url}")
        download_file(url, TMP)
        if valid_file(TMP):
            TMP.replace(TARGET)
            print(f"Zapisano poprawny plik: {TARGET}")
            break
        print("Pobrany plik ma zly format, probuje kolejny adres")
    except Exception as error:
        last_error = error
        print(f"Nie udalo sie pobrac z tego adresu: {url}")
else:
    if TMP.exists():
        TMP.unlink()
    raise RuntimeError(f"Nie udalo sie pobrac poprawnych danych. Ostatni blad: {last_error}")

if TMP.exists():
    TMP.unlink()
