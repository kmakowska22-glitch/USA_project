from pathlib import Path
import pandas as pd
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HTML = ROOT / "html"
OUTPUT = ROOT / "output"
HTML.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)

usa = pd.read_csv(DATA / "covid_usa.csv", parse_dates=["date"])
usa = usa.sort_values("date")

vaccination_columns = [column for column in ["people_vaccinated_per_hundred", "people_fully_vaccinated_per_hundred", "total_boosters_per_hundred", "total_vaccinations_per_hundred"] if column in usa.columns]
if vaccination_columns:
    long = usa.melt(id_vars="date", value_vars=vaccination_columns, var_name="metric", value_name="value").dropna()
    fig = px.line(long, x="date", y="value", color="metric", title="COVID-19 in the USA: vaccination progress", labels={"date": "Date", "value": "Per 100 people", "metric": "Metric"})
    fig.update_layout(template="plotly_dark", hovermode="x unified")
    fig.write_html(HTML / "10_usa_vaccination_progress.html")

if {"people_fully_vaccinated_per_hundred", "new_deaths_smoothed_per_million"}.issubset(usa.columns):
    relation = usa[["date", "people_fully_vaccinated_per_hundred", "new_deaths_smoothed_per_million"]].dropna().copy()
    relation["month"] = relation["date"].dt.to_period("M").dt.to_timestamp()
    relation = relation.groupby("month", as_index=False).agg({"people_fully_vaccinated_per_hundred": "mean", "new_deaths_smoothed_per_million": "mean"})
    relation.to_csv(OUTPUT / "usa_vaccination_deaths_monthly_relation.csv", index=False)
    fig2 = px.scatter(relation, x="people_fully_vaccinated_per_hundred", y="new_deaths_smoothed_per_million", animation_frame=relation["month"].dt.strftime("%Y-%m"), size="new_deaths_smoothed_per_million", title="COVID-19 in the USA: vaccination level and deaths over time", labels={"people_fully_vaccinated_per_hundred": "Fully vaccinated per 100", "new_deaths_smoothed_per_million": "Deaths per million, 7-day average"})
    fig2.update_layout(template="plotly_dark")
    fig2.write_html(HTML / "11_usa_vaccination_deaths_animation.html")

if {"new_vaccinations_smoothed", "new_cases_smoothed"}.issubset(usa.columns):
    selected = usa[["date", "new_vaccinations_smoothed", "new_cases_smoothed"]].dropna().copy()
    selected.to_csv(OUTPUT / "usa_vaccinations_cases_timeseries.csv", index=False)
    long2 = selected.melt(id_vars="date", value_vars=["new_vaccinations_smoothed", "new_cases_smoothed"], var_name="metric", value_name="value")
    fig3 = px.line(long2, x="date", y="value", color="metric", title="COVID-19 in the USA: vaccinations and cases, 7-day averages", labels={"date": "Date", "value": "Count", "metric": "Metric"})
    fig3.update_layout(template="plotly_dark", hovermode="x unified")
    fig3.write_html(HTML / "12_usa_vaccinations_cases.html")
