from pathlib import Path
import pandas as pd
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HTML = ROOT / "html"
OUTPUT = ROOT / "output"
HTML.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA / "covid_usa_pol_world.csv", parse_dates=["date"])
df = df[df["iso_code"].isin(["USA", "POL"])].copy()
df.to_csv(OUTPUT / "usa_vs_poland_data.csv", index=False)

if "new_cases_smoothed_per_million" in df.columns:
    fig = px.line(df, x="date", y="new_cases_smoothed_per_million", color="location", title="COVID-19: USA vs Poland, new cases per million, 7-day average", labels={"date": "Date", "new_cases_smoothed_per_million": "New cases per million", "location": "Country"})
    fig.update_layout(template="plotly_dark", hovermode="x unified")
    fig.write_html(HTML / "07_usa_vs_poland_cases_per_million.html")

if "new_deaths_smoothed_per_million" in df.columns:
    fig2 = px.line(df, x="date", y="new_deaths_smoothed_per_million", color="location", title="COVID-19: USA vs Poland, new deaths per million, 7-day average", labels={"date": "Date", "new_deaths_smoothed_per_million": "New deaths per million", "location": "Country"})
    fig2.update_layout(template="plotly_dark", hovermode="x unified")
    fig2.write_html(HTML / "08_usa_vs_poland_deaths_per_million.html")

compare_columns = [column for column in ["total_cases_per_million", "total_deaths_per_million", "case_fatality_rate", "people_fully_vaccinated_per_hundred"] if column in df.columns]
latest = []
for location, group in df.groupby("location"):
    row = {"location": location}
    for column in compare_columns:
        valid = group[["date", column]].dropna()
        row[column] = valid.iloc[-1][column] if not valid.empty else None
    latest.append(row)
latest = pd.DataFrame(latest)
latest.to_csv(OUTPUT / "usa_vs_poland_latest_comparison.csv", index=False)
if compare_columns:
    long = latest.melt(id_vars="location", value_vars=compare_columns, var_name="metric", value_name="value")
    fig3 = px.bar(long, x="metric", y="value", color="location", barmode="group", title="COVID-19: USA vs Poland, latest available indicators", labels={"metric": "Metric", "value": "Value", "location": "Country"})
    fig3.update_layout(template="plotly_dark")
    fig3.write_html(HTML / "09_usa_vs_poland_latest_indicators.html")
