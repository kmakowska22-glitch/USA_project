from pathlib import Path
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HTML = ROOT / "html"
OUTPUT = ROOT / "output"
HTML.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)

usa = pd.read_csv(DATA / "covid_usa.csv", parse_dates=["date"])
usa = usa.sort_values("date")

fig = make_subplots(rows=2, cols=1, shared_xaxes=True, subplot_titles=("New cases, 7-day average", "New deaths, 7-day average"))
if "new_cases_smoothed" in usa.columns:
    fig.add_trace(go.Scatter(x=usa["date"], y=usa["new_cases_smoothed"], name="New cases smoothed", mode="lines"), row=1, col=1)
if "new_deaths_smoothed" in usa.columns:
    fig.add_trace(go.Scatter(x=usa["date"], y=usa["new_deaths_smoothed"], name="New deaths smoothed", mode="lines"), row=2, col=1)
fig.update_layout(title="COVID-19 in the USA: smoothed daily trends", template="plotly_dark", height=760, hovermode="x unified")
fig.write_html(HTML / "04_usa_daily_trends.html")

columns = [column for column in ["total_cases", "total_deaths"] if column in usa.columns]
long = usa.melt(id_vars="date", value_vars=columns, var_name="metric", value_name="value")
fig2 = px.line(long, x="date", y="value", color="metric", log_y=True, title="COVID-19 in the USA: cumulative cases and deaths on log scale", labels={"date": "Date", "value": "Cumulative count", "metric": "Metric"})
fig2.update_layout(template="plotly_dark", hovermode="x unified")
fig2.write_html(HTML / "05_usa_cumulative_log.html")

peaks = []
if "new_cases_smoothed" in usa.columns:
    case_peaks = usa[["date", "new_cases_smoothed"]].dropna().nlargest(10, "new_cases_smoothed")
    case_peaks["metric"] = "new_cases_smoothed"
    case_peaks = case_peaks.rename(columns={"new_cases_smoothed": "value"})
    peaks.append(case_peaks)
if "new_deaths_smoothed" in usa.columns:
    death_peaks = usa[["date", "new_deaths_smoothed"]].dropna().nlargest(10, "new_deaths_smoothed")
    death_peaks["metric"] = "new_deaths_smoothed"
    death_peaks = death_peaks.rename(columns={"new_deaths_smoothed": "value"})
    peaks.append(death_peaks)
if peaks:
    peak_table = pd.concat(peaks, ignore_index=True).sort_values(["metric", "value"], ascending=[True, False])
    peak_table.to_csv(OUTPUT / "usa_top_peaks.csv", index=False)
    fig3 = px.bar(peak_table, x="date", y="value", color="metric", facet_row="metric", title="COVID-19 in the USA: top reported peak days", labels={"date": "Date", "value": "7-day average", "metric": "Metric"})
    fig3.update_layout(template="plotly_dark", showlegend=False)
    fig3.write_html(HTML / "06_usa_top_peaks.html")
