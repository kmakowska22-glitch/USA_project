from pathlib import Path
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
HTML = ROOT / "html"
OUTPUT = ROOT / "output"
HTML.mkdir(exist_ok=True)
OUTPUT.mkdir(exist_ok=True)

usa = pd.read_csv(DATA / "covid_usa.csv", parse_dates=["date"])
usa = usa.sort_values("date")


def latest_value(frame, column):
    if column not in frame.columns:
        return None, None
    values = frame[["date", column]].dropna()
    if values.empty:
        return None, None
    row = values.iloc[-1]
    return row["date"].date().isoformat(), row[column]

metrics = [
    ("Total cases", "total_cases"),
    ("Total deaths", "total_deaths"),
    ("Total cases per million", "total_cases_per_million"),
    ("Total deaths per million", "total_deaths_per_million"),
    ("Case fatality rate (%)", "case_fatality_rate"),
    ("People fully vaccinated per 100", "people_fully_vaccinated_per_hundred")
]

rows = []
for name, column in metrics:
    date, value = latest_value(usa, column)
    rows.append({"metric": name, "column": column, "date": date, "value": value})

summary = pd.DataFrame(rows)
summary.to_csv(OUTPUT / "usa_summary_statistics.csv", index=False)

fig = make_subplots(rows=2, cols=3, specs=[[{"type": "indicator"}, {"type": "indicator"}, {"type": "indicator"}], [{"type": "indicator"}, {"type": "indicator"}, {"type": "indicator"}]])
for index, row in summary.iterrows():
    r = index // 3 + 1
    c = index % 3 + 1
    fig.add_trace(go.Indicator(mode="number", value=0 if pd.isna(row["value"]) else row["value"], title={"text": row["metric"]}, number={"valueformat": ",.2f"}), row=r, col=c)
fig.update_layout(title="COVID-19 in the USA: latest summary statistics", template="plotly_dark", height=650)
fig.write_html(HTML / "01_usa_summary_statistics.html")

annual_columns = [column for column in ["new_cases", "new_deaths"] if column in usa.columns]
annual = usa.dropna(subset=["date"]).copy()
annual["year"] = annual["date"].dt.year
annual = annual.groupby("year", as_index=False)[annual_columns].sum(min_count=1)
annual.to_csv(OUTPUT / "usa_annual_cases_deaths.csv", index=False)
annual_long = annual.melt(id_vars="year", value_vars=annual_columns, var_name="metric", value_name="value")
fig2 = px.bar(annual_long, x="year", y="value", color="metric", barmode="group", title="COVID-19 in the USA: annual cases and deaths", labels={"year": "Year", "value": "Count", "metric": "Metric"})
fig2.update_layout(template="plotly_dark")
fig2.write_html(HTML / "02_usa_annual_cases_deaths.html")

monthly = usa.copy()
monthly["month"] = monthly["date"].dt.to_period("M").dt.to_timestamp()
monthly = monthly.groupby("month", as_index=False)[annual_columns].sum(min_count=1)
monthly.to_csv(OUTPUT / "usa_monthly_cases_deaths.csv", index=False)
monthly_long = monthly.melt(id_vars="month", value_vars=annual_columns, var_name="metric", value_name="value")
fig3 = px.area(monthly_long, x="month", y="value", color="metric", title="COVID-19 in the USA: monthly reported cases and deaths", labels={"month": "Month", "value": "Count", "metric": "Metric"})
fig3.update_layout(template="plotly_dark", hovermode="x unified")
fig3.write_html(HTML / "03_usa_monthly_cases_deaths.html")
