from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
SOURCE = DATA / "compact.csv"

COUNTRIES = ["USA", "POL", "OWID_WRL"]
BASE_COLUMNS = [
    "iso_code", "continent", "location", "date", "population",
    "total_cases", "new_cases", "new_cases_smoothed", "total_cases_per_million", "new_cases_per_million", "new_cases_smoothed_per_million",
    "total_deaths", "new_deaths", "new_deaths_smoothed", "total_deaths_per_million", "new_deaths_per_million", "new_deaths_smoothed_per_million",
    "reproduction_rate", "icu_patients", "icu_patients_per_million", "hosp_patients", "hosp_patients_per_million",
    "weekly_icu_admissions", "weekly_icu_admissions_per_million", "weekly_hosp_admissions", "weekly_hosp_admissions_per_million",
    "total_tests", "new_tests", "new_tests_smoothed", "positive_rate", "tests_per_case", "new_tests_smoothed_per_thousand",
    "total_vaccinations", "people_vaccinated", "people_fully_vaccinated", "total_boosters", "new_vaccinations_smoothed",
    "total_vaccinations_per_hundred", "people_vaccinated_per_hundred", "people_fully_vaccinated_per_hundred", "total_boosters_per_hundred",
    "stringency_index", "median_age", "aged_65_older", "gdp_per_capita", "human_development_index", "life_expectancy"
]


def first_existing(columns, frame):
    return [column for column in columns if column in frame.columns]


def safe_divide(a, b):
    return np.where((pd.notna(a)) & (pd.notna(b)) & (b != 0), a / b, np.nan)


print("Czytam dane")
df = pd.read_csv(SOURCE)
required = {"iso_code", "location", "date"}
missing = sorted(required - set(df.columns))
if missing:
    raise ValueError(f"Brakuje kolumn: {missing}. Usun data\\compact.csv i uruchom setup_and_run.ps1 jeszcze raz.")

df["date"] = pd.to_datetime(df["date"], errors="coerce")
df = df[df["iso_code"].isin(COUNTRIES)].copy()
df = df[first_existing(BASE_COLUMNS, df)].sort_values(["location", "date"])

if {"total_deaths", "total_cases"}.issubset(df.columns):
    df["case_fatality_rate"] = safe_divide(df["total_deaths"], df["total_cases"]) * 100

if {"new_cases_smoothed", "new_deaths_smoothed"}.issubset(df.columns):
    df["deaths_cases_ratio_21d"] = df.groupby("location")["new_deaths_smoothed"].shift(-21)
    df["deaths_cases_ratio_21d"] = safe_divide(df["deaths_cases_ratio_21d"], df["new_cases_smoothed"]) * 100

processed = DATA / "covid_usa_pol_world.csv"
usa = DATA / "covid_usa.csv"
df.to_csv(processed, index=False)
df[df["iso_code"] == "USA"].to_csv(usa, index=False)
print(f"Zapisano: {processed}")
print(f"Zapisano: {usa}")
